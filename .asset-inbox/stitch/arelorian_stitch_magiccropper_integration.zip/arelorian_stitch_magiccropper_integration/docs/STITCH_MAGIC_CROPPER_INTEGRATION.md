# Stitch Loot UI + Magic Cropper Integration

## Nutzen
Das hochgeladene Stitch-Paket ist wertvoll für Arelorian/WASD, weil es fertige UI-Prototypen, Rarity-Icons, Affix-Icons, Monsterklassen, Kingdom-/Faction-Symbole und modulare Sprite-Sheets enthält. Der beste Weg ist nicht, alles blind in die Engine zu werfen, sondern es als deterministischen Visual-Layer zu behandeln.

## Zielpfad
- Input: `stitch_arelorian_loot_ui_system/`
- Output: `client/public/assets/stitch-loot-ui/`
- Manifest: `client/public/assets/stitch-loot-ui/manifest.json`
- Crop-Manifest: `client/public/assets/stitch-loot-ui/crop-manifest.json`

## Installation
```bash
pnpm add -D sharp
node scripts/import-stitch-loot-ui.mjs ./stitch_arelorian_loot_ui_system ./client/public/assets/stitch-loot-ui
node scripts/magic-cropper-stitch.mjs ./client/public/assets/stitch-loot-ui 0.05
```

## Determinismus-Regel
Der Server entscheidet Rarity, Affixe, Item-Seed und Authority-Signatur. Der Client rendert nur die passenden Icons aus dem Manifest. Keine Loot-Entscheidung darf im UI passieren.

## Integration
1. Scripts nach `scripts/` kopieren.
2. Client-Dateien nach `client/src/ui/loot/` kopieren.
3. Server-Datei nach `server/src/loot/` kopieren.
4. `stitchLoot.css` einmal im HUD/Portal importieren.
5. Bei Loot-Spawn `resolveLootVisualPayload(item, tick, WORLD_SEED)` mitschicken.
6. Im Client `loadStitchLootManifest()` laden und `LootVisualRegistry` bauen.

## Magic Cropper Policy
- Alpha-Bounds croppen.
- 5% Padding beibehalten, damit dicke Outlines nicht abgeschnitten werden.
- Original `screen.png` nie überschreiben.
- Crops als `screen.cropped.png` danebenlegen.
