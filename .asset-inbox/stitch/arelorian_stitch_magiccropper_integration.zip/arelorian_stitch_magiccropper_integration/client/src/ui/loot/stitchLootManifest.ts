export type StitchAssetCategory = 'rarity' | 'affix' | 'monster' | 'faction' | 'jewelry' | 'sheet' | 'dashboard' | 'misc';

export interface StitchAssetManifestEntry {
  id: string;
  originalName: string;
  category: StitchAssetCategory;
  kind: string;
  src: string;
  croppedSrc: string;
  hasHtmlPrototype: boolean;
  deterministic: true;
}

export interface StitchAssetManifest {
  version: 1;
  generatedAt: string;
  assets: StitchAssetManifestEntry[];
}

let cache: Promise<StitchAssetManifest> | null = null;

export function loadStitchLootManifest(): Promise<StitchAssetManifest> {
  cache ??= fetch('/assets/stitch-loot-ui/manifest.json', { cache: 'force-cache' })
    .then((res) => {
      if (!res.ok) throw new Error(`STITCH_MANIFEST_LOAD_FAILED:${res.status}`);
      return res.json() as Promise<StitchAssetManifest>;
    });
  return cache;
}
