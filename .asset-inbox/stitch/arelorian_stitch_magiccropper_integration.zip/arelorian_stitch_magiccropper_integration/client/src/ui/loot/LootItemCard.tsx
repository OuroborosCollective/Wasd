import React from 'react';
import type { ItemRarity } from './lootVisualRegistry';
import { LootVisualRegistry } from './lootVisualRegistry';

export interface LootAffixView {
  id: string;
  kind: string;
  label: string;
  value: number | string;
}

export interface LootItemView {
  id: string;
  name: string;
  itemLevel: number;
  rarity: ItemRarity;
  baseType: string;
  powerScore: number;
  seed: string;
  affixes: LootAffixView[];
}

const rarityClass: Record<ItemRarity, string> = {
  COMMON: 'stitch-common', MAGIC: 'stitch-magic', RARE: 'stitch-rare', EPIC: 'stitch-epic', LEGENDARY: 'stitch-legendary', MYTHIC: 'stitch-mythic',
};

export function LootItemCard({ item, registry }: { item: LootItemView; registry: LootVisualRegistry }) {
  const rarityIcon = registry.iconForRarity(item.rarity);
  return (
    <article className={`stitch-loot-card ${rarityClass[item.rarity]}`} data-item-id={item.id} data-seed={item.seed}>
      <header className="stitch-loot-head">
        {rarityIcon ? <img className="stitch-rarity-icon" src={rarityIcon} alt="" /> : null}
        <div>
          <h3>{item.name}</h3>
          <p>{item.rarity} · {item.baseType} · ilvl {item.itemLevel}</p>
        </div>
        <strong>{item.powerScore}</strong>
      </header>
      <section className="stitch-affixes">
        {item.affixes.map((affix) => {
          const icon = registry.iconForAffix(affix.kind);
          return <div className="stitch-affix" key={affix.id}>{icon ? <img src={icon} alt="" /> : null}<span>{affix.label}</span><b>{affix.value}</b></div>;
        })}
      </section>
    </article>
  );
}
