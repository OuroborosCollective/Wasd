import type { StitchAssetManifest, StitchAssetManifestEntry } from './stitchLootManifest';

export type ItemRarity = 'COMMON' | 'MAGIC' | 'RARE' | 'EPIC' | 'LEGENDARY' | 'MYTHIC';
export type AffixVisualKind =
  | 'strength' | 'agility' | 'intelligence' | 'mana' | 'life' | 'luck'
  | 'crit_chance' | 'crit_damage' | 'fire_resistance' | 'ice_resistance'
  | 'lightning_resistance' | 'poison' | 'vampirism' | 'cooldown_reduction'
  | 'speed' | 'dodge' | 'defense' | 'block_chance' | 'area_of_effect';

const rarityKind: Record<ItemRarity, string> = {
  COMMON: 'rarity', MAGIC: 'rarity', RARE: 'rarity', EPIC: 'rarity', LEGENDARY: 'rarity', MYTHIC: 'rarity',
};

function byIdContains(assets: StitchAssetManifestEntry[], needle: string) {
  return assets.find((a) => a.id.toLowerCase().includes(needle.toLowerCase()));
}

export class LootVisualRegistry {
  private byKind = new Map<string, StitchAssetManifestEntry>();
  private byId = new Map<string, StitchAssetManifestEntry>();

  constructor(manifest: StitchAssetManifest) {
    for (const asset of manifest.assets) {
      this.byId.set(asset.id, asset);
      if (!this.byKind.has(asset.kind)) this.byKind.set(asset.kind, asset);
    }
  }

  iconForAffix(kind: string): string | undefined {
    return this.byKind.get(kind)?.croppedSrc ?? this.byKind.get(kind)?.src;
  }

  iconForRarity(rarity: ItemRarity): string | undefined {
    const id = `${rarity.toLowerCase()}_icon`;
    const asset = this.byId.get(id) ?? byIdContains([...this.byId.values()], id);
    return asset?.croppedSrc ?? asset?.src;
  }

  asset(id: string): StitchAssetManifestEntry | undefined {
    return this.byId.get(id);
  }
}
