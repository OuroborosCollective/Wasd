#!/usr/bin/env node
import { mkdir, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();
const assetRoot = process.argv[2] ?? './client/public/assets/stitch-loot-ui';
const padding = Number(process.argv[3] ?? 0.05);

let sharp;
try {
  sharp = (await import('sharp')).default;
} catch {
  console.error('Missing dependency: pnpm add -D sharp');
  process.exit(1);
}

async function cropPng(input, output) {
  const image = sharp(input).ensureAlpha();
  const { data, info } = await image.raw().toBuffer({ resolveWithObject: true });
  let minX = info.width, minY = info.height, maxX = -1, maxY = -1;
  for (let y = 0; y < info.height; y++) {
    for (let x = 0; x < info.width; x++) {
      const alpha = data[(y * info.width + x) * info.channels + 3];
      if (alpha > 8) { minX = Math.min(minX, x); minY = Math.min(minY, y); maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); }
    }
  }
  if (maxX < minX || maxY < minY) return null;
  const padX = Math.ceil((maxX - minX + 1) * padding);
  const padY = Math.ceil((maxY - minY + 1) * padding);
  const left = Math.max(0, minX - padX);
  const top = Math.max(0, minY - padY);
  const right = Math.min(info.width - 1, maxX + padX);
  const bottom = Math.min(info.height - 1, maxY + padY);
  const width = right - left + 1;
  const height = bottom - top + 1;
  await sharp(input).extract({ left, top, width, height }).png({ compressionLevel: 9 }).toFile(output);
  return { left, top, width, height, sourceWidth: info.width, sourceHeight: info.height };
}

const dirs = await readdir(assetRoot, { withFileTypes: true });
const crops = [];
for (const d of dirs) {
  if (!d.isDirectory()) continue;
  const input = join(assetRoot, d.name, 'screen.png');
  const output = join(assetRoot, d.name, 'screen.cropped.png');
  try {
    const crop = await cropPng(input, output);
    if (crop) crops.push({ id: d.name, ...crop, output: `/assets/stitch-loot-ui/${d.name}/screen.cropped.png` });
  } catch (err) {
    console.warn(`skip ${d.name}: ${err.message}`);
  }
}
await writeFile(join(assetRoot, 'crop-manifest.json'), JSON.stringify({ version: 1, padding, crops }, null, 2));
console.log(`Magic-cropped ${crops.length} Stitch assets.`);
