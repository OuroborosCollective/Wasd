#!/usr/bin/env node
import { cp, mkdir, readdir, readFile, writeFile, stat } from 'node:fs/promises';
import { join, basename } from 'node:path';

const root = process.cwd();
const source = process.argv[2] ?? './stitch_arelorian_loot_ui_system';
const outDir = process.argv[3] ?? './client/public/assets/stitch-loot-ui';

const categoryRules = [
  ['rarity', /^(common|magic|rare|epic|legendary|mythic)_icon$/],
  ['affix', /(affix|resistance|chance|crit|vampirismus|schadensreflexion|abklingzeit|defense|dodge|life|mana|luck|speed|strength|agility|intelligence|poison|block|area_of_effect)/],
  ['monster', /(monster|beast|demon|angel|goblin|humanoid|reptile|amphibian|fairy|elemental|alien|holo|machine|ai_being|physics|psi|secretion)/],
  ['faction', /(faction|kingdom|land_symbol|army_rank|npc_army|trust_badge|universal_npc)/],
  ['jewelry', /^jewelry_/],
  ['sheet', /sprite_sheet|design_sheet|modular_2d|procedural_/],
  ['dashboard', /(dashboard|archive|editor|modeler|showcase|integration)/],
];

function inferCategory(id) {
  for (const [category, rx] of categoryRules) if (rx.test(id)) return category;
  return 'misc';
}

function inferKind(id) {
  if (/common|magic|rare|epic|legendary|mythic/.test(id)) return 'rarity';
  if (/strength/.test(id)) return 'strength';
  if (/agility/.test(id)) return 'agility';
  if (/intelligence/.test(id)) return 'intelligence';
  if (/mana/.test(id)) return 'mana';
  if (/life/.test(id)) return 'life';
  if (/luck/.test(id)) return 'luck';
  if (/crit_damage/.test(id)) return 'crit_damage';
  if (/crit/.test(id)) return 'crit_chance';
  if (/fire/.test(id)) return 'fire_resistance';
  if (/ice/.test(id)) return 'ice_resistance';
  if (/lightning/.test(id)) return 'lightning_resistance';
  if (/poison/.test(id)) return 'poison';
  if (/vampirismus/.test(id)) return 'vampirism';
  if (/cooldown|abklingzeit/.test(id)) return 'cooldown_reduction';
  if (/speed/.test(id)) return 'speed';
  if (/dodge/.test(id)) return 'dodge';
  if (/defense/.test(id)) return 'defense';
  if (/block/.test(id)) return 'block_chance';
  if (/area_of_effect/.test(id)) return 'area_of_effect';
  return id;
}

async function exists(path) {
  try { await stat(path); return true; } catch { return false; }
}

await mkdir(outDir, { recursive: true });
const entries = await readdir(source, { withFileTypes: true });
const manifest = [];

for (const entry of entries) {
  if (!entry.isDirectory()) continue;
  const id = entry.name.replace(/[^a-zA-Z0-9_./-]/g, '_').replaceAll('.', '').replaceAll('/', '_');
  const srcDir = join(source, entry.name);
  const screen = join(srcDir, 'screen.png');
  const code = join(srcDir, 'code.html');
  if (!(await exists(screen))) continue;

  const destDir = join(outDir, id);
  await mkdir(destDir, { recursive: true });
  await cp(screen, join(destDir, 'screen.png'));
  if (await exists(code)) await cp(code, join(destDir, 'code.html'));

  manifest.push({
    id,
    originalName: entry.name,
    category: inferCategory(entry.name),
    kind: inferKind(entry.name),
    src: `/assets/stitch-loot-ui/${id}/screen.png`,
    croppedSrc: `/assets/stitch-loot-ui/${id}/screen.cropped.png`,
    hasHtmlPrototype: await exists(code),
    deterministic: true,
  });
}

manifest.sort((a, b) => `${a.category}:${a.id}`.localeCompare(`${b.category}:${b.id}`));
await writeFile(join(outDir, 'manifest.json'), JSON.stringify({ version: 1, generatedAt: new Date(0).toISOString(), assets: manifest }, null, 2));
console.log(`Imported ${manifest.length} Stitch assets into ${outDir}`);
