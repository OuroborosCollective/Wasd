export type ItemRarity = 'COMMON' | 'MAGIC' | 'RARE' | 'EPIC' | 'LEGENDARY' | 'MYTHIC';

export interface GeneratedLootItem {
  id: string;
  seed: string;
  rarity: ItemRarity;
  baseType: string;
  affixes: Array<{ id: string; modifierType: string; value: number }>;
}

export interface LootVisualPayload {
  itemId: string;
  seed: string;
  rarity: ItemRarity;
  rarityAssetId: string;
  affixAssetIds: string[];
  authoritySignature: string;
}

const AFFIX_TO_VISUAL: Record<string, string> = {
  strength: 'affix_icon_strength', agility: 'agility_icon_1', intelligence: 'intelligence_icon',
  mana: 'affix_icon_mana', life: 'life_affix_icon', luck: 'luck_affix_icon',
  crit_chance: 'affix_icon_crit', crit_damage: 'crit_damage_affix_icon',
  fire_resistance: 'fire_resistance_icon', ice_resistance: 'ice_resistance_icon', lightning_resistance: 'lightning_resistance_icon',
  poison: 'poison_affix_icon', vampirism: 'vampirismus_icon', cooldown_reduction: 'abklingzeit_reduktion_icon',
  speed: 'speed_affix_icon', dodge: 'dodge_affix_icon', defense: 'defense_affix_icon', block_chance: 'block_chance_icon', area_of_effect: 'area_of_effect_affix_icon',
};

function fnv1a(input: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) { h ^= input.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(16).padStart(8, '0');
}

export function resolveLootVisualPayload(item: GeneratedLootItem, tick: number, worldSeed: string): LootVisualPayload {
  const rarityAssetId = `${item.rarity.toLowerCase()}_icon`;
  const affixAssetIds = item.affixes.map((a) => AFFIX_TO_VISUAL[a.modifierType] ?? 'magic_icon');
  const material = [worldSeed, tick, item.id, item.seed, item.rarity, rarityAssetId, ...affixAssetIds].join('|');
  return { itemId: item.id, seed: item.seed, rarity: item.rarity, rarityAssetId, affixAssetIds, authoritySignature: `BSE-1000:${fnv1a(material)}` };
}
