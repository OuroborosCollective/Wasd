# Areloria Character Forge — PixiJS Ready

Procedurally generated 2.5D MMORPG character sprites for use with PixiJS,
Phaser, or any sprite-sheet-compatible game engine. Designed for WASD/Areloria
asset pipelines.

## Contents

```
character-atlas/
  ATTRIBUTION.md        ← OpenGameArt-style asset credits + quality summary
  LICENSE               ← GPL-3.0
  README.md             ← This file
  atlas.png             ← Combined atlas (all characters packed)
  manifest.json         ← PixiJS Spritesheet manifest (frame coords + animations + anchors)
  characters.json       ← Full metadata per character (class, race, quality score)
  metadata.jsonl        ← One JSON record per character (dataset format)
  quality-report.json   ← Per-character and per-frame quality analysis
  characters/
    warrior/            ← Individual 192×576 sprite sheets
    mage/
    rogue/
    ranger/
    paladin/
    berserker/
```

## Sprite Sheet Layout (per character: 192×576 px)

| Row | Animation    | Frames | Notes       |
|-----|--------------|--------|-------------|
|  0  | walk_south   |   4    | Full        |
|  1  | walk_west    |   4    | Full        |
|  2  | walk_east    |   4    | Full        |
|  3  | walk_north   |   4    | Full        |
|  4  | idle         |   4    | Full        |
|  5  | attack       |   4    | Full        |
|  6  | cast         |   4    | Fallback    |
|  7  | hurt         |   4    | Fallback    |
|  8  | death        |   4    | Fallback    |

Frame size: 48×64 px — Transparent PNG — No anti-aliasing

## PixiJS Usage

```typescript
import { Assets, AnimatedSprite } from "pixi.js";

const sheet = await Assets.load("character-atlas/manifest.json");

const char = new AnimatedSprite(
  sheet.animations["char_warrior_human_iron_uncommon_01__walk_south"]
);
char.animationSpeed = 0.12;
char.loop = true;
char.play();
app.stage.addChild(char);

// Switch to attack
char.textures = sheet.animations["char_warrior_human_iron_uncommon_01__attack"];
char.play();
```

## License

GPL-3.0 — see LICENSE file.
Creator: OuroborosCollective
Repository: https://github.com/OuroborosCollective/2.5d_pixi_weapon_atlas_generatordeterministic
